// Configuration - Live API Gateway endpoints
const API_CONFIG = {
    IMAGE_PROCESSOR_URL: 'https://kias3m04sg.execute-api.us-east-1.amazonaws.com/prod/process-image',
    CHAT_URL: 'https://kias3m04sg.execute-api.us-east-1.amazonaws.com/prod/chat'
};

// Global variables
let currentDescription = '';
let currentAudio = null;

// DOM Elements
const imageInput = document.getElementById('imageInput');
const imagePreview = document.getElementById('imagePreview');
const previewImg = document.getElementById('previewImg');
const processBtn = document.getElementById('processBtn');
const clearBtn = document.getElementById('clearBtn');
const processingStatus = document.getElementById('processingStatus');
const resultsSection = document.getElementById('resultsSection');
const errorDisplay = document.getElementById('errorDisplay');
const errorMessage = document.getElementById('errorMessage');
const descriptionText = document.getElementById('descriptionText');
const audioPlayer = document.getElementById('audioPlayer');
const playBtn = document.getElementById('playBtn');
const pauseBtn = document.getElementById('pauseBtn');
const questionInput = document.getElementById('questionInput');
const askBtn = document.getElementById('askBtn');
const chatHistory = document.getElementById('chatHistory');

// Event Listeners
imageInput.addEventListener('change', handleImageSelect);
processBtn.addEventListener('click', processImage);
clearBtn.addEventListener('click', clearImage);
playBtn.addEventListener('click', playAudio);
pauseBtn.addEventListener('click', pauseAudio);
askBtn.addEventListener('click', askQuestion);
questionInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') askQuestion();
});

// Quick question buttons
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('quick-question')) {
        questionInput.value = e.target.textContent;
        askQuestion();
    }
});

// Audio player events
audioPlayer.addEventListener('play', () => {
    playBtn.classList.add('hidden');
    pauseBtn.classList.remove('hidden');
});

audioPlayer.addEventListener('pause', () => {
    playBtn.classList.remove('hidden');
    pauseBtn.classList.add('hidden');
});

audioPlayer.addEventListener('ended', () => {
    playBtn.classList.remove('hidden');
    pauseBtn.classList.add('hidden');
});

// Functions
function handleImageSelect(event) {
    const file = event.target.files[0];
    if (!file) return;

    // Validate file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
        showError('File size must be less than 10MB');
        return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
        showError('Please select a valid image file');
        return;
    }

    // Show preview
    const reader = new FileReader();
    reader.onload = (e) => {
        previewImg.src = e.target.result;
        imagePreview.classList.remove('hidden');
        hideError();
        hideResults();
    };
    reader.readAsDataURL(file);
}

function clearImage() {
    imageInput.value = '';
    imagePreview.classList.add('hidden');
    hideResults();
    hideError();
    hideProcessing();
}

async function processImage() {
    const file = imageInput.files[0];
    if (!file) {
        showError('Please select an image first');
        return;
    }

    showProcessing();
    hideError();
    hideResults();

    try {
        // Convert image to base64
        const base64Image = await fileToBase64(file);
        
        // Send to API
        const response = await fetch(API_CONFIG.IMAGE_PROCESSOR_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                image: base64Image
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        
        if (result.success) {
            displayResults(result);
        } else {
            throw new Error(result.error || 'Processing failed');
        }

    } catch (error) {
        console.error('Error processing image:', error);
        showError('Failed to process image. Please try again.');
    } finally {
        hideProcessing();
    }
}

function displayResults(result) {
    currentDescription = result.description;
    
    // Display description
    descriptionText.textContent = result.description;
    
    // Setup audio
    if (result.audio_base64) {
        const audioBlob = base64ToBlob(result.audio_base64, 'audio/mp3');
        const audioUrl = URL.createObjectURL(audioBlob);
        audioPlayer.src = audioUrl;
    }
    
    // Clear previous chat
    chatHistory.innerHTML = '';
    
    // Show results
    resultsSection.classList.remove('hidden');
    
    // Auto-play audio
    setTimeout(() => {
        audioPlayer.play().catch(e => console.log('Auto-play prevented:', e));
    }, 500);
}

async function askQuestion() {
    const question = questionInput.value.trim();
    if (!question) return;

    if (!currentDescription) {
        showError('Please process an image first');
        return;
    }

    // Add question to chat
    addChatMessage(question, 'user');
    questionInput.value = '';
    
    // Show loading
    const loadingId = addChatMessage('Thinking...', 'assistant', true);

    try {
        const response = await fetch(API_CONFIG.CHAT_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                question: question,
                original_description: currentDescription
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        
        // Remove loading message
        document.getElementById(loadingId).remove();
        
        if (result.success) {
            // Add answer to chat
            const messageId = addChatMessage(result.answer, 'assistant');
            
            // Setup audio for answer
            if (result.audio_base64) {
                const audioBlob = base64ToBlob(result.audio_base64, 'audio/mp3');
                const audioUrl = URL.createObjectURL(audioBlob);
                addAudioToMessage(messageId, audioUrl);
            }
        } else {
            throw new Error(result.error || 'Failed to get answer');
        }

    } catch (error) {
        console.error('Error asking question:', error);
        document.getElementById(loadingId).remove();
        addChatMessage('Sorry, I encountered an error. Please try again.', 'assistant');
    }
}

function addChatMessage(message, sender, isLoading = false) {
    const messageId = 'msg-' + Date.now();
    const messageDiv = document.createElement('div');
    messageDiv.id = messageId;
    messageDiv.className = `flex ${sender === 'user' ? 'justify-end' : 'justify-start'}`;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = `max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
        sender === 'user' 
            ? 'bg-blue-600 text-white' 
            : 'bg-gray-100 text-gray-800'
    }`;
    
    if (isLoading) {
        contentDiv.innerHTML = `<i class="fas fa-spinner fa-spin mr-2"></i>${message}`;
    } else {
        contentDiv.textContent = message;
    }
    
    messageDiv.appendChild(contentDiv);
    chatHistory.appendChild(messageDiv);
    chatHistory.scrollTop = chatHistory.scrollHeight;
    
    return messageId;
}

function addAudioToMessage(messageId, audioUrl) {
    const messageDiv = document.getElementById(messageId);
    const contentDiv = messageDiv.querySelector('div');
    
    const audioContainer = document.createElement('div');
    audioContainer.className = 'mt-2';
    
    const audioElement = document.createElement('audio');
    audioElement.src = audioUrl;
    audioElement.controls = true;
    audioElement.className = 'w-full';
    
    audioContainer.appendChild(audioElement);
    contentDiv.appendChild(audioContainer);
    
    // Auto-play the answer
    setTimeout(() => {
        audioElement.play().catch(e => console.log('Auto-play prevented:', e));
    }, 300);
}

function playAudio() {
    audioPlayer.play();
}

function pauseAudio() {
    audioPlayer.pause();
}

function showProcessing() {
    processingStatus.classList.remove('hidden');
}

function hideProcessing() {
    processingStatus.classList.add('hidden');
}

function showResults() {
    resultsSection.classList.remove('hidden');
}

function hideResults() {
    resultsSection.classList.add('hidden');
}

function showError(message) {
    errorMessage.textContent = message;
    errorDisplay.classList.remove('hidden');
}

function hideError() {
    errorDisplay.classList.add('hidden');
}

// Utility functions
function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

function base64ToBlob(base64, mimeType) {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mimeType });
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    console.log('SeeWrite AI initialized');
    hideError();
    hideResults();
    hideProcessing();
});