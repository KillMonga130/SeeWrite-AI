// Configuration - Live API Gateway endpoints
const API_CONFIG = {
    IMAGE_PROCESSOR_URL: 'https://kias3m04sg.execute-api.us-east-1.amazonaws.com/prod/process-image',
    CHAT_URL: 'https://kias3m04sg.execute-api.us-east-1.amazonaws.com/prod/chat',
    AUDIO_URL: 'https://kias3m04sg.execute-api.us-east-1.amazonaws.com/prod/generate-audio'
};

// Global variables
let currentDescription = '';
let currentAudio = null;
let allAudioElements = [];

// DOM Elements
const imageInput = document.getElementById('imageInput');
const imagePreview = document.getElementById('imagePreview');
const previewImg = document.getElementById('previewImg');
const processBtn = document.getElementById('processBtn');
const clearBtn = document.getElementById('clearBtn');
const processingStatus = document.getElementById('processingStatus');
const resultsSection = document.getElementById('resultsSection');
const errorDisplay = document.getElementById('errorDisplay');
const errorMessage = document.getElementById('errorMessage');
const descriptionText = document.getElementById('descriptionText');
const audioPlayer = document.getElementById('audioPlayer');
const playBtn = document.getElementById('playBtn');
const pauseBtn = document.getElementById('pauseBtn');
const questionInput = document.getElementById('questionInput');
const askBtn = document.getElementById('askBtn');
const chatHistory = document.getElementById('chatHistory');

// Event Listeners
imageInput.addEventListener('change', handleImageSelect);
processBtn.addEventListener('click', processImage);
clearBtn.addEventListener('click', clearImage);
playBtn.addEventListener('click', playAudio);
pauseBtn.addEventListener('click', pauseAudio);
askBtn.addEventListener('click', askQuestion);
questionInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') askQuestion();
});

// Quick question buttons
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('quick-question')) {
        questionInput.value = e.target.textContent;
        askQuestion();
    }
});

// Audio player events
audioPlayer.addEventListener('play', () => {
    playBtn.classList.add('hidden');
    pauseBtn.classList.remove('hidden');
});

audioPlayer.addEventListener('pause', () => {
    playBtn.classList.remove('hidden');
    pauseBtn.classList.add('hidden');
});

audioPlayer.addEventListener('ended', () => {
    playBtn.classList.remove('hidden');
    pauseBtn.classList.add('hidden');
});

// Functions
function handleImageSelect(event) {
    const file = event.target.files[0];
    if (!file) return;

    // Validate file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
        showError('File size must be less than 10MB');
        return;
    }

    // Validate file type
    if (!file.type.startsWith('image/')) {
        showError('Please select a valid image file');
        return;
    }

    // Show preview
    const reader = new FileReader();
    reader.onload = (e) => {
        previewImg.src = e.target.result;
        imagePreview.classList.remove('hidden');
        hideError();
        hideResults();
    };
    reader.readAsDataURL(file);
}

function clearImage() {
    imageInput.value = '';
    imagePreview.classList.add('hidden');
    hideResults();
    hideError();
    hideProcessing();
}

async function processImage() {
    const file = imageInput.files[0];
    if (!file) {
        showError('Please select an image first');
        return;
    }

    showProcessing();
    hideError();
    hideResults();

    try {
        // Convert image to base64
        const base64Image = await fileToBase64(file);
        
        // Send to API for text generation only
        const response = await fetch(API_CONFIG.IMAGE_PROCESSOR_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                image: base64Image
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        
        if (result.success) {
            displayResultsOptimized(result);
        } else {
            throw new Error(result.error || 'Processing failed');
        }

    } catch (error) {
        console.error('Error processing image:', error);
        showError('Failed to process image. Please try again.');
    } finally {
        hideProcessing();
    }
}

function displayResultsOptimized(result) {
    currentDescription = result.description;
    
    // Show results section first
    resultsSection.classList.remove('hidden');
    
    // Clear previous content
    descriptionText.innerHTML = '';
    chatHistory.innerHTML = '';
    
    // Stream text with typing effect
    streamText(result.description, descriptionText);
    
    // Setup on-demand audio generation
    setupOnDemandAudio(result.description);
}

function streamText(text, element) {
    const words = text.split(' ');
    let currentIndex = 0;
    
    function addNextWord() {
        if (currentIndex < words.length) {
            const word = words[currentIndex];
            const span = document.createElement('span');
            span.textContent = word + ' ';
            span.style.opacity = '0';
            span.style.transform = 'translateY(10px)';
            span.style.transition = 'all 0.3s ease';
            
            element.appendChild(span);
            
            // Trigger animation
            setTimeout(() => {
                span.style.opacity = '1';
                span.style.transform = 'translateY(0)';
            }, 10);
            
            currentIndex++;
            setTimeout(addNextWord, 50); // Adjust speed here
        }
    }
    
    addNextWord();
}

function setupOnDemandAudio(text) {
    // Clear previous audio
    audioPlayer.src = '';
    
    // Update play button to generate audio on demand
    playBtn.onclick = () => generateAndPlayAudio(text);
    
    // Show play button, hide pause button
    playBtn.classList.remove('hidden');
    pauseBtn.classList.add('hidden');
}

async function askQuestion() {
    const question = questionInput.value.trim();
    if (!question) return;

    if (!currentDescription) {
        showError('Please process an image first');
        return;
    }

    // Add question to chat
    addChatMessage(question, 'user');
    questionInput.value = '';
    
    // Show loading
    const loadingId = addChatMessage('Thinking...', 'assistant', true);

    try {
        const response = await fetch(API_CONFIG.CHAT_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                question: question,
                original_description: currentDescription
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        
        // Remove loading message
        document.getElementById(loadingId).remove();
        
        if (result.success) {
            // Add answer to chat with streaming effect
            const messageId = addChatMessageStreaming(result.answer, 'assistant');
            
            // Setup on-demand audio for answer
            addOnDemandAudioToMessage(messageId, result.answer);
        } else {
            throw new Error(result.error || 'Failed to get answer');
        }

    } catch (error) {
        console.error('Error asking question:', error);
        document.getElementById(loadingId).remove();
        addChatMessage('Sorry, I encountered an error. Please try again.', 'assistant');
    }
}

function addChatMessage(message, sender, isLoading = false) {
    const messageId = 'msg-' + Date.now();
    const messageDiv = document.createElement('div');
    messageDiv.id = messageId;
    messageDiv.className = `chat-message flex ${sender === 'user' ? 'justify-end' : 'justify-start'} ${sender}`;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = `message-bubble ${sender} px-4 py-2 rounded-lg`;
    
    if (isLoading) {
        contentDiv.innerHTML = `<i class="fas fa-spinner fa-spin mr-2"></i>${message}`;
    } else {
        contentDiv.textContent = message;
    }
    
    messageDiv.appendChild(contentDiv);
    chatHistory.appendChild(messageDiv);
    chatHistory.scrollTop = chatHistory.scrollHeight;
    
    return messageId;
}

function addChatMessageStreaming(message, sender) {
    const messageId = 'msg-' + Date.now();
    const messageDiv = document.createElement('div');
    messageDiv.id = messageId;
    messageDiv.className = `chat-message flex ${sender === 'user' ? 'justify-end' : 'justify-start'} ${sender}`;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = `message-bubble ${sender} px-4 py-2 rounded-lg`;
    
    messageDiv.appendChild(contentDiv);
    chatHistory.appendChild(messageDiv);
    chatHistory.scrollTop = chatHistory.scrollHeight;
    
    // Stream the text
    streamText(message, contentDiv);
    
    return messageId;
}

function addOnDemandAudioToMessage(messageId, text) {
    const messageDiv = document.getElementById(messageId);
    const contentDiv = messageDiv.querySelector('div');
    
    const audioContainer = document.createElement('div');
    audioContainer.className = 'mt-2 flex items-center space-x-2';
    
    const playButton = document.createElement('button');
    playButton.className = 'bg-blue-500 text-white px-3 py-1 rounded-full text-sm hover:bg-blue-600 transition-colors';
    playButton.innerHTML = '<i class="fas fa-play mr-1"></i>Play Audio';
    
    const loadingSpinner = document.createElement('span');
    loadingSpinner.className = 'hidden text-blue-500';
    loadingSpinner.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
    
    playButton.onclick = () => generateChatAudio(text, playButton, loadingSpinner, audioContainer);
    
    audioContainer.appendChild(playButton);
    audioContainer.appendChild(loadingSpinner);
    contentDiv.appendChild(audioContainer);
}

async function generateAndPlayAudio(text) {
    try {
        // Show loading state
        playBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        playBtn.disabled = true;
        
        const response = await fetch(API_CONFIG.AUDIO_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ text: text })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.success) {
            const audioBlob = base64ToBlob(result.audio_base64, 'audio/mp3');
            const audioUrl = URL.createObjectURL(audioBlob);
            audioPlayer.src = audioUrl;
            
            // Add to audio elements array
            if (!allAudioElements.includes(audioPlayer)) {
                allAudioElements.push(audioPlayer);
            }
            
            // Add event listener to stop other audio when this plays
            audioPlayer.addEventListener('play', stopOtherAudio);
            
            // Play the audio
            audioPlayer.play();
        } else {
            throw new Error(result.error || 'Audio generation failed');
        }
    } catch (error) {
        console.error('Error generating audio:', error);
        showError('Failed to generate audio. Please try again.');
    } finally {
        // Reset button state
        playBtn.innerHTML = '<i class="fas fa-play"></i>';
        playBtn.disabled = false;
    }
}

async function generateChatAudio(text, button, spinner, container) {
    try {
        // Show loading state
        button.classList.add('hidden');
        spinner.classList.remove('hidden');
        
        const response = await fetch(API_CONFIG.AUDIO_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ text: text })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.success) {
            const audioBlob = base64ToBlob(result.audio_base64, 'audio/mp3');
            const audioUrl = URL.createObjectURL(audioBlob);
            
            // Create audio element
            const audioElement = document.createElement('audio');
            audioElement.src = audioUrl;
            audioElement.controls = true;
            audioElement.className = 'w-full mt-2';
            
            // Add to audio elements array
            allAudioElements.push(audioElement);
            
            // Add event listener to stop other audio when this plays
            audioElement.addEventListener('play', stopOtherAudio);
            
            // Replace button with audio player
            container.innerHTML = '';
            container.appendChild(audioElement);
            
            // Auto-play
            setTimeout(() => {
                audioElement.play().catch(e => console.log('Auto-play prevented:', e));
            }, 300);
        } else {
            throw new Error(result.error || 'Audio generation failed');
        }
    } catch (error) {
        console.error('Error generating audio:', error);
        // Reset button state
        button.classList.remove('hidden');
        spinner.classList.add('hidden');
    }
}

function playAudio() {
    if (audioPlayer.src) {
        audioPlayer.play();
    }
}

function pauseAudio() {
    audioPlayer.pause();
}

function stopOtherAudio(event) {
    const currentAudio = event.target;
    allAudioElements.forEach(audio => {
        if (audio !== currentAudio && !audio.paused) {
            audio.pause();
        }
    });
}

function showProcessing() {
    processingStatus.classList.remove('hidden');
}

function hideProcessing() {
    processingStatus.classList.add('hidden');
}

function showResults() {
    resultsSection.classList.remove('hidden');
}

function hideResults() {
    resultsSection.classList.add('hidden');
}

function showError(message) {
    errorMessage.textContent = message;
    errorDisplay.classList.remove('hidden');
}

function hideError() {
    errorDisplay.classList.add('hidden');
}

// Utility functions
function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

function base64ToBlob(base64, mimeType) {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mimeType });
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    console.log('SeeWrite AI initialized - Optimized for fast text response');
    hideError();
    hideResults();
    hideProcessing();
});