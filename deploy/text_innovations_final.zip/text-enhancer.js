// Advanced Text Enhancement Engine
class TextEnhancer {
    constructor() {
        this.definitions = {
            '6G': 'Sixth generation wireless technology',
            'AI': 'Artificial Intelligence',
            'ML': 'Machine Learning',
            'IoT': 'Internet of Things',
            'API': 'Application Programming Interface'
        };
        this.userLevel = localStorage.getItem('user-level') || 'intermediate';
    }

    enhanceText(text, container) {
        const enhanced = this.processText(text);
        this.renderEnhancedText(enhanced, container);
        this.addInteractiveElements(container);
    }

    processText(text) {
        return {
            original: text,
            summary: this.generateSummary(text),
            keyTerms: this.extractKeyTerms(text),
            sections: this.createSections(text),
            questions: this.generateQuestions(text),
            actionItems: this.extractActionItems(text)
        };
    }

    generateSummary(text) {
        const sentences = text.split('.').filter(s => s.trim().length > 20);
        return sentences.slice(0, 3).join('. ') + '.';
    }

    extractKeyTerms(text) {
        const terms = text.match(/\b[A-Z]{2,}\b|\b\d+G\b|framework|algorithm|model|system|network/gi) || [];
        return [...new Set(terms)].slice(0, 8);
    }

    createSections(text) {
        const sentences = text.split('.');
        const sections = [];
        for (let i = 0; i < sentences.length; i += 3) {
            sections.push({
                title: this.generateSectionTitle(sentences.slice(i, i + 3).join('.')),
                content: sentences.slice(i, i + 3).join('.') + '.',
                expanded: false
            });
        }
        return sections;
    }

    generateSectionTitle(content) {
        const keywords = content.match(/\b[A-Z][a-z]+\b/g) || [];
        return keywords.slice(0, 3).join(' ') || 'Key Information';
    }

    generateQuestions(text) {
        const questions = [
            'How does this work in practice?',
            'What are the key benefits?',
            'What challenges might arise?',
            'How does this compare to alternatives?',
            'What are the next steps?'
        ];
        return questions.slice(0, 3);
    }

    extractActionItems(text) {
        const actions = [];
        if (text.includes('develop')) actions.push('Consider development opportunities');
        if (text.includes('test')) actions.push('Plan testing strategies');
        if (text.includes('implement')) actions.push('Explore implementation paths');
        return actions.slice(0, 3);
    }

    renderEnhancedText(enhanced, container) {
        container.innerHTML = `
            <div class="enhanced-text-container">
                <!-- Quick Summary -->
                <div class="summary-card">
                    <h4><i class="fas fa-lightbulb"></i> Quick Summary</h4>
                    <p>${enhanced.summary}</p>
                </div>

                <!-- Key Terms -->
                <div class="key-terms">
                    <h4><i class="fas fa-tags"></i> Key Terms</h4>
                    <div class="terms-grid">
                        ${enhanced.keyTerms.map(term => 
                            `<span class="key-term" data-term="${term}">${term}</span>`
                        ).join('')}
                    </div>
                </div>

                <!-- Expandable Sections -->
                <div class="sections-container">
                    <h4><i class="fas fa-list"></i> Detailed Breakdown</h4>
                    ${enhanced.sections.map((section, i) => `
                        <div class="expandable-section" data-section="${i}">
                            <div class="section-header">
                                <span>${section.title}</span>
                                <i class="fas fa-chevron-down"></i>
                            </div>
                            <div class="section-content hidden">
                                ${this.highlightText(section.content)}
                            </div>
                        </div>
                    `).join('')}
                </div>

                <!-- Follow-up Questions -->
                <div class="questions-card">
                    <h4><i class="fas fa-question-circle"></i> Explore Further</h4>
                    <div class="questions-list">
                        ${enhanced.questions.map(q => 
                            `<button class="question-btn" data-question="${q}">${q}</button>`
                        ).join('')}
                    </div>
                </div>

                <!-- Action Items -->
                ${enhanced.actionItems.length > 0 ? `
                    <div class="action-items">
                        <h4><i class="fas fa-tasks"></i> Action Items</h4>
                        <ul>
                            ${enhanced.actionItems.map(item => `<li>${item}</li>`).join('')}
                        </ul>
                    </div>
                ` : ''}

                <!-- Difficulty Toggle -->
                <div class="difficulty-controls">
                    <label>Explanation Level:</label>
                    <select class="level-selector">
                        <option value="beginner">Beginner</option>
                        <option value="intermediate" selected>Intermediate</option>
                        <option value="advanced">Advanced</option>
                    </select>
                </div>
            </div>
        `;
    }

    highlightText(text) {
        return text
            .replace(/(\b[A-Z]{2,}\b)/g, '<span class="acronym" title="Click for definition">$1</span>')
            .replace(/(\d+G|\d+\.\d+)/g, '<span class="highlight-number">$1</span>')
            .replace(/(framework|algorithm|model|system|network)/gi, '<span class="highlight-term">$1</span>');
    }

    addInteractiveElements(container) {
        // Expandable sections
        container.querySelectorAll('.expandable-section').forEach(section => {
            section.querySelector('.section-header').onclick = () => {
                const content = section.querySelector('.section-content');
                const icon = section.querySelector('i');
                content.classList.toggle('hidden');
                icon.classList.toggle('fa-chevron-down');
                icon.classList.toggle('fa-chevron-up');
            };
        });

        // Key terms tooltips
        container.querySelectorAll('.key-term').forEach(term => {
            term.onclick = () => {
                const definition = this.definitions[term.dataset.term] || 'Definition not available';
                this.showTooltip(term, definition);
            };
        });

        // Question buttons
        container.querySelectorAll('.question-btn').forEach(btn => {
            btn.onclick = () => {
                document.getElementById('questionInput').value = btn.dataset.question;
                document.getElementById('askBtn').click();
            };
        });

        // Difficulty level
        container.querySelector('.level-selector').onchange = (e) => {
            this.userLevel = e.target.value;
            localStorage.setItem('user-level', this.userLevel);
            this.adjustContentLevel(container, this.userLevel);
        };

        // Acronym definitions
        container.querySelectorAll('.acronym').forEach(acronym => {
            acronym.onclick = () => {
                const definition = this.definitions[acronym.textContent] || 'Definition not available';
                this.showTooltip(acronym, definition);
            };
        });
    }

    showTooltip(element, text) {
        const tooltip = document.createElement('div');
        tooltip.className = 'definition-tooltip';
        tooltip.textContent = text;
        
        const rect = element.getBoundingClientRect();
        tooltip.style.position = 'absolute';
        tooltip.style.top = (rect.bottom + 5) + 'px';
        tooltip.style.left = rect.left + 'px';
        
        document.body.appendChild(tooltip);
        
        setTimeout(() => tooltip.remove(), 3000);
    }

    adjustContentLevel(container, level) {
        const complexity = {
            beginner: 'Simple explanations with basic terms',
            intermediate: 'Balanced technical detail',
            advanced: 'Full technical complexity'
        };
        
        // Add level indicator
        let indicator = container.querySelector('.level-indicator');
        if (!indicator) {
            indicator = document.createElement('div');
            indicator.className = 'level-indicator';
            container.prepend(indicator);
        }
        indicator.textContent = `Level: ${level} - ${complexity[level]}`;
    }
}

// Initialize text enhancer
window.textEnhancer = new TextEnhancer();