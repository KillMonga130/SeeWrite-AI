// API Configuration
const API_CONFIG = {
    IMAGE_PROCESSOR_URL: 'https://your-api-gateway-url/prod/process-image',
    CHAT_URL: 'https://your-api-gateway-url/prod/chat',
    AUDIO_URL: 'https://your-api-gateway-url/prod/generate-audio'
};

// Global state
let currentDescription = '';
let currentAudio = null;

// DOM Elements
const elements = {
    imageInput: document.getElementById('imageInput'),
    imagePreview: document.getElementById('imagePreview'),
    previewImg: document.getElementById('previewImg'),
    processBtn: document.getElementById('processBtn'),
    clearBtn: document.getElementById('clearBtn'),
    processingStatus: document.getElementById('processingStatus'),
    resultsSection: document.getElementById('resultsSection'),
    errorDisplay: document.getElementById('errorDisplay'),
    errorMessage: document.getElementById('errorMessage'),
    descriptionText: document.getElementById('descriptionText'),
    audioPlayer: document.getElementById('audioPlayer'),
    playAudioBtn: document.getElementById('playAudioBtn'),
    questionInput: document.getElementById('questionInput'),
    askBtn: document.getElementById('askBtn'),
    chatHistory: document.getElementById('chatHistory')
};

// Event Listeners
function initializeEventListeners() {
    elements.imageInput.addEventListener('change', handleImageSelect);
    elements.processBtn.addEventListener('click', processImage);
    elements.clearBtn.addEventListener('click', clearImage);
    elements.playAudioBtn.addEventListener('click', playMainAudio);
    elements.askBtn.addEventListener('click', askQuestion);
    elements.questionInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') askQuestion();
    });

    // Quick question buttons
    document.addEventListener('click', (e) => {
        if (e.target.classList.contains('quick-question')) {
            elements.questionInput.value = e.target.textContent;
            askQuestion();
        }
    });
}

// Image handling
function handleImageSelect(event) {
    const file = event.target.files[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
        showError('File size must be less than 10MB');
        return;
    }

    if (!file.type.startsWith('image/')) {
        showError('Please select a valid image file');
        return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
        elements.previewImg.src = e.target.result;
        elements.imagePreview.classList.remove('hidden');
        hideError();
        hideResults();
    };
    reader.readAsDataURL(file);
}

function clearImage() {
    elements.imageInput.value = '';
    elements.imagePreview.classList.add('hidden');
    hideResults();
    hideError();
    hideProcessing();
    currentDescription = '';
    if (currentAudio) {
        currentAudio.pause();
        currentAudio = null;
    }
}

// Image processing
async function processImage() {
    const file = elements.imageInput.files[0];
    if (!file) {
        showError('Please select an image first');
        return;
    }

    showProcessing();
    hideError();
    hideResults();

    try {
        const base64Image = await fileToBase64(file);
        
        const response = await fetch(API_CONFIG.IMAGE_PROCESSOR_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                image: base64Image
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        
        if (result.success) {
            displayResults(result);
        } else {
            throw new Error(result.error || 'Processing failed');
        }

    } catch (error) {
        console.error('Error processing image:', error);
        showError('Failed to process image. Please try again.');
    } finally {
        hideProcessing();
    }
}

function displayResults(result) {
    currentDescription = result.description;
    
    elements.resultsSection.classList.remove('hidden');
    elements.descriptionText.textContent = result.description;
    elements.chatHistory.innerHTML = '';
    
    // Setup audio if available
    if (result.audio_base64) {
        setupMainAudio(result.audio_base64);
    }
}

function setupMainAudio(audioBase64) {
    const audioBlob = base64ToBlob(audioBase64, 'audio/mp3');
    const audioUrl = URL.createObjectURL(audioBlob);
    elements.audioPlayer.src = audioUrl;
    elements.audioPlayer.style.display = 'block';
    
    elements.playAudioBtn.onclick = () => {
        if (currentAudio && !currentAudio.paused) {
            currentAudio.pause();
        }
        currentAudio = elements.audioPlayer;
        elements.audioPlayer.play();
    };
}

function playMainAudio() {
    if (elements.audioPlayer.src) {
        elements.audioPlayer.play();
    }
}

// Q&A functionality
async function askQuestion() {
    const question = elements.questionInput.value.trim();
    if (!question) return;

    if (!currentDescription) {
        showError('Please process an image first');
        return;
    }

    addChatMessage(question, 'user');
    elements.questionInput.value = '';
    
    const loadingId = addChatMessage('Thinking...', 'ai', true);

    try {
        const response = await fetch(API_CONFIG.CHAT_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                question: question,
                original_description: currentDescription
            })
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        
        document.getElementById(loadingId).remove();
        
        if (result.success) {
            const messageId = addChatMessage(result.answer, 'ai');
            if (result.audio_base64) {
                addAudioToMessage(messageId, result.audio_base64);
            }
        } else {
            throw new Error(result.error || 'Failed to get answer');
        }

    } catch (error) {
        console.error('Error asking question:', error);
        document.getElementById(loadingId).remove();
        addChatMessage('Sorry, I encountered an error. Please try again.', 'ai');
    }
}

function addChatMessage(message, sender, isLoading = false) {
    const messageId = 'msg-' + Date.now();
    const messageDiv = document.createElement('div');
    messageDiv.id = messageId;
    messageDiv.className = `flex ${sender === 'user' ? 'justify-end' : 'justify-start'} mb-4`;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = `max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
        sender === 'user' ? 'message-user' : 'message-ai'
    }`;
    
    if (isLoading) {
        contentDiv.innerHTML = `<i class="fas fa-spinner fa-spin mr-2"></i>${message}`;
    } else {
        contentDiv.textContent = message;
    }
    
    messageDiv.appendChild(contentDiv);
    elements.chatHistory.appendChild(messageDiv);
    elements.chatHistory.scrollTop = elements.chatHistory.scrollHeight;
    
    return messageId;
}

function addAudioToMessage(messageId, audioBase64) {
    const messageDiv = document.getElementById(messageId);
    if (!messageDiv) return;
    
    const contentDiv = messageDiv.querySelector('div');
    
    const audioContainer = document.createElement('div');
    audioContainer.className = 'mt-2';
    
    const playButton = document.createElement('button');
    playButton.className = 'bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded text-sm transition-colors';
    playButton.innerHTML = '<i class="fas fa-play mr-1"></i>Play Audio';
    
    playButton.onclick = () => playMessageAudio(audioBase64, playButton);
    
    audioContainer.appendChild(playButton);
    contentDiv.appendChild(audioContainer);
}

function playMessageAudio(audioBase64, button) {
    if (currentAudio && !currentAudio.paused) {
        currentAudio.pause();
    }
    
    const audioBlob = base64ToBlob(audioBase64, 'audio/mp3');
    const audioUrl = URL.createObjectURL(audioBlob);
    
    const audio = new Audio(audioUrl);
    currentAudio = audio;
    
    button.innerHTML = '<i class="fas fa-pause mr-1"></i>Playing...';
    button.disabled = true;
    
    audio.onended = () => {
        button.innerHTML = '<i class="fas fa-play mr-1"></i>Play Audio';
        button.disabled = false;
    };
    
    audio.play();
}

// UI state management
function showProcessing() {
    elements.processingStatus.classList.remove('hidden');
}

function hideProcessing() {
    elements.processingStatus.classList.add('hidden');
}

function showResults() {
    elements.resultsSection.classList.remove('hidden');
}

function hideResults() {
    elements.resultsSection.classList.add('hidden');
}

function showError(message) {
    elements.errorMessage.textContent = message;
    elements.errorDisplay.classList.remove('hidden');
}

function hideError() {
    elements.errorDisplay.classList.add('hidden');
}

// Utility functions
function fileToBase64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });
}

function base64ToBlob(base64, mimeType) {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: mimeType });
}

// Initialize app
document.addEventListener('DOMContentLoaded', () => {
    initializeEventListeners();
    hideError();
    hideResults();
    hideProcessing();
    console.log('SeeWrite AI - Application loaded successfully');
});